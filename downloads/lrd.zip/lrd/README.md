LibertyReserved is crypto currency payment system based on NXT code.

Libertyreserved - is most advanced cryptocurrency payment system that combines
the transparency of transactions with anonymity of paying agents. With LRD you
can buy and sell goods and services, make money transfers with a minimum fee
on the market (only 1 LRD per transaction of any size). LRD has an investment
program with the best conditions, with which you can build your passive income.
In addition, you can participate in the network and receive reward in the form
of the transfer fee.

LRD allows you to:
- buy/sell goods and services
- transfer coins to any another user with minimal fee on market (only 1 LRD for transaction any size)
- take a part in our investment program (info here)
- create your own assets nominated in LRD (for example - something like our Lottery service)

Requirements:
Java 8 compatible JVM. Only the Oracle JVM has been tested and supported

Setup:
Please open conf/lrd-default.properties in a text editor,
and add your IP to the line lrd.myAddress=, so it looks like
"nxt.myAddress=11.11.11.11", and forward port 888 if behind a NAT.
This is not required, but will help the network.

Usage:
Run run.sh or run.bat to start the server. The interface is accessed through
a web browser on port 8888. ex: http://127.0.0.1:8888 or http://localhost:8888

Pick a long passphrase, as it is the only thing needed to access your account.