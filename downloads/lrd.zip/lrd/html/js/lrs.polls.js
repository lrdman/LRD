/******************************************************************************
 * Copyright © 2013-2015 The Nxt Core Developers.                             *
 *                                                                            *
 * See the AUTHORS.txt, DEVELOPER-AGREEMENT.txt and LICENSE.txt files at      *
 * the top-level directory of this distribution for the individual copyright  *
 * holder information and the developer policies on copyright and licensing.  *
 *                                                                            *
 * Unless otherwise agreed in a custom licensing agreement, no part of the    *
 * Nxt software, including this file, may be copied, modified, propagated,    *
 * or distributed except according to the terms contained in the LICENSE.txt  *
 * file.                                                                      *
 *                                                                            *
 * Removal or modification of this copyright notice is prohibited.            *
 *                                                                            *
 ******************************************************************************/

/**
 * @depends {lrs.js}
 */
var LRS = (function(LRS, $, undefined) {
	
	var _voteCache = {};

	function _setFollowButtonStates() {
		if (LRS.databaseSupport) {
			LRS.database.select("polls", null, function(error, polls) {
				$.each(polls, function(index, poll) {
					$('.follow_button:visible[data-follow="' + poll.poll + '"]').attr('disabled', true);
				});
			});
		}
	}

	function _setVoteButtonStates() {
		$('.vote_button:visible[data-poll]').each(function(index, btn) {
			var pollID = $(btn).data('poll');
			if (pollID in _voteCache) {
				$(btn).attr('disabled', true);
			} else {
				LRS.sendRequest("getPollVote", {
					"account": LRS.account,
					"poll": pollID
				}, function(response) {
					if (response && response.voterRS) {
						$(btn).attr('disabled', true);
						_voteCache[pollID] = response;
					} else {
						$(btn).attr('disabled', false);
					}
				});
			}
		});
	}

	LRS.pages.polls = function() {
		LRS.sendRequest("getPolls+", {
			"firstIndex": LRS.pageNumber * LRS.itemsPerPage - LRS.itemsPerPage,
			"lastIndex": LRS.pageNumber * LRS.itemsPerPage,
			"includeFinished": false
		}, function(response) {
			if (response.polls && response.polls.length) {
				var polls = {};
				var nrPolls = 0;

				if (response.polls.length > LRS.itemsPerPage) {
					LRS.hasMorePages = true;
					response.polls.pop();
				}

				for (var i = 0; i < response.polls.length; i++) {
					LRS.sendRequest("getTransaction+", {
						"transaction": response.polls[i].poll
					}, function(poll, input) {
						if (LRS.currentPage != "polls") {
							polls = {};
							return;
						}

						if (!poll.errorCode) {
							polls[input.transaction] = poll;
						}

						nrPolls++;


						if (nrPolls == response.polls.length) {
							var rows = "";

							for (var i = 0; i < nrPolls; i++) {
								var poll = polls[response.polls[i].poll];

								if (!poll) {
									continue;
								}

								var pollDescription = String(poll.attachment.description);

								if (pollDescription.length > 100) {
									pollDescription = pollDescription.substring(0, 100) + "...";
								}
								rows += "<tr>";
								rows += "<td><a class='poll_list_title show_transaction_modal_action' href='#' data-transaction='"+poll.transaction+"'>" + String(poll.attachment.name).escapeHTML() + "</a></td>";
								rows += "<td>" + pollDescription.escapeHTML() + "</td>";
								rows += "<td>" + (poll.sender != LRS.constants.GENESIS ? "<a href='#' data-user='" + LRS.getAccountFormatted(poll, "sender") + "' class='show_account_modal_action user_info'>" + LRS.getAccountTitle(poll, "sender") + "</a>" : "Genesis") + "</td>";
								rows += "<td>" + LRS.formatTimestamp(poll.timestamp) + "</td>";
								rows += "<td style='text-align:center;'>" + String(poll.attachment.finishHeight - LRS.lastBlockHeight) + "</td>";
								rows += "<td style='text-align:center;'><nobr><a href='#' class='vote_button btn btn-xs btn-default' data-poll='" + poll.transaction +"'>" + $.t('vote_btn_short') + "</a> ";
								rows += "<a href='#' class='follow_button btn btn-xs btn-default' data-follow='" + poll.transaction + "'>" + $.t('vote_follow_btn_short') + "</a></nobr></td>";
								rows += "</tr>";
							}
							LRS.dataLoaded(rows);
							_setFollowButtonStates();
							_setVoteButtonStates();
						}
					});
				}
			} else {
				LRS.dataLoaded();
			}
		});
	}
 
	LRS.incoming.polls = function() {
		LRS.loadPage("polls");
	}

	LRS.pages.my_polls = function() {
		LRS.sendRequest("getPolls+", {
			"account": LRS.account,
			"includeFinished": true
		}, function(response) {
			if (response.polls && response.polls.length) {
				var polls = {};
				var nrPolls = 0;

				for (var i = 0; i < response.polls.length; i++) {
					LRS.sendRequest("getTransaction+", {
						"transaction": response.polls[i].poll
					}, function(poll, input) {
						if (LRS.currentPage != "my_polls") {
							polls = {};
							return;
						}

						if (!poll.errorCode) {
							polls[input.transaction] = poll;
						}

						nrPolls++;


						if (nrPolls == response.polls.length) {
							var rows = "";

							for (var i = 0; i < nrPolls; i++) {
								var poll = polls[response.polls[i].poll];

								if (!poll) {
									continue;
								}

								var pollDescription = String(poll.attachment.description);

								if (pollDescription.length > 100) {
									pollDescription = pollDescription.substring(0, 100) + "...";
								}
								rows += "<tr>"
								rows += "<td><a class='poll_list_title show_transaction_modal_action' href='#'  data-transaction='"+poll.transaction+"'>" + String(poll.attachment.name).escapeHTML() + "</a></td>";
								rows += "<td>" + pollDescription.escapeHTML() + "</td>";
								rows += "<td>" + (poll.sender != LRS.constants.GENESIS ? "<a href='#' data-user='" + LRS.getAccountFormatted(poll, "sender") + "' class='show_account_modal_action user_info'>" + LRS.getAccountTitle(poll, "sender") + "</a>" : "Genesis") + "</td>"
								rows += "<td>" + LRS.formatTimestamp(poll.timestamp) + "</td>";
								if(poll.attachment.finishHeight > LRS.lastBlockHeight)
								{
									rows += "<td style='text-align:center;'>" + String(poll.attachment.finishHeight - LRS.lastBlockHeight) + "</td>";
									rows += "<td style='text-align:center;'><a href='#' class='vote_button btn btn-xs btn-default' data-poll='" + poll.transaction +"'>" + $.t('vote_btn_short') + "</a> ";
								}
								else
								{
									rows += "<td style='text-align:center;'>" + $.t('complete') + "</td>";
									rows += "<td style='text-align:center;'><a href='#' class='results_button btn btn-xs btn-default' data-results='" + poll.transaction +"'>" + $.t('vote_results_btn_short') + "</a> ";
								}
								rows += "<a href='#' class='follow_button btn btn-xs btn-default' data-follow='" + poll.transaction + "'>" + $.t('vote_follow_btn_short') + "</a></td>";
								rows += "</tr>";
							}
							LRS.dataLoaded(rows);
							_setFollowButtonStates();
							_setVoteButtonStates();
						}
					});
				}
			} else {
				LRS.dataLoaded();
			}
		});
	}

	LRS.incoming.my_polls = function() {
		LRS.loadPage("my_polls");
	}

	LRS.pages.voted_polls = function() {
		LRS.sendRequest("getBlockchainTransactions",{"account": LRS.accountRS, "type": 1, "subtype": 3}, function(response) {
			
			if (response.transactions && response.transactions.length > 0) {
				var polls = {};
				var nrPolls = 0;

				for (var i = 0; i < response.transactions.length; i++) {
					LRS.sendRequest("getTransaction", {
						"transaction": response.transactions[i].attachment.poll
					}, function(poll, input) {
						if (LRS.currentPage != "voted_polls") {
							polls = {};
							return;
						}

						if (!poll.errorCode) {
							polls[input.transaction] = poll;
						}

						nrPolls++;

						if (nrPolls == response.transactions.length) {
							var rows = "";

							for (var i = 0; i < nrPolls; i++) {
								var poll = polls[response.transactions[i].attachment.poll];

								if (!poll) {
									continue;
								}
								var pollDescription = String(poll.attachment.description);

								if (pollDescription.length > 100) {
									pollDescription = pollDescription.substring(0, 100) + "...";
								}
								rows += "<tr>"
								rows += "<td><a class='poll_list_title show_transaction_modal_action' href='#' data-transaction='"+poll.transaction+"'>" + String(poll.attachment.name).escapeHTML() + "</a></td>";
								rows += "<td>" + pollDescription.escapeHTML() + "</td>";
								rows += "<td>" + (poll.sender != LRS.constants.GENESIS ? "<a href='#' data-user='" + LRS.getAccountFormatted(poll, "sender") + "' class='show_account_modal_action user_info'>" + LRS.getAccountTitle(poll, "sender") + "</a>" : "Genesis") + "</td>"
								rows += "<td>" + LRS.formatTimestamp(poll.timestamp) + "</td>";
								if(poll.attachment.finishHeight > LRS.lastBlockHeight)
								{
									rows += "<td style='text-align:center;'>" + String(poll.attachment.finishHeight - LRS.lastBlockHeight) + "</td>";
									rows += "<td style='text-align:center;'>-</td>";

								}
								else
								{
									rows += "<td style='text-align:center;'>" + $.t('complete') + "</td>";
									rows += "<td style='text-align:center;'><a href='#' class='results_button btn btn-xs btn-default' data-results='" + poll.transaction +"'>" + $.t('vote_results_btn_short') + "</a></td>";
								}
								rows += "<td style='text-align:center;'><a href='#' class='follow_button btn btn-xs btn-default' data-follow='" + poll.transaction + "'>" + $.t('vote_follow_btn_short') + "</a></td>";
								rows += "</tr>";
							}
							LRS.dataLoaded(rows);
							_setFollowButtonStates();
						}
					});
				}
			} else {
				LRS.dataLoaded();
			}
		});
	}

	LRS.incoming.voted_polls = function() {
		LRS.loadPage("voted_polls");
	}

	LRS.setup.polls = function() {
		var sidebarId = 'sidebar_voting_system';
		var options = {
			"id": sidebarId,
			"titleHTML": '<i class="fa fa-check-square-o"></i><span data-i18n="voting_system">Voting</span>',
			"page": 'polls',
			"desiredPosition": 50
		}
		LRS.addTreeviewSidebarMenuItem(options);
		options = {
			"titleHTML": '<span data-i18n="active_polls">Active Polls</span>',
			"type": 'PAGE',
			"page": 'polls'
		}
		LRS.appendMenuItemToTSMenuItem(sidebarId, options);
		options = {
			"titleHTML": '<span data-i18n="followed_polls">Followed Polls</span>',
			"type": 'PAGE',
			"page": 'followed_polls'
		}
		LRS.appendMenuItemToTSMenuItem(sidebarId, options);
		options = {
			"titleHTML": '<span data-i18n="my_votes">My Votes</span>',
			"type": 'PAGE',
			"page": 'voted_polls'
		}
		LRS.appendMenuItemToTSMenuItem(sidebarId, options);
		options = {
			"titleHTML": '<span data-i18n="my_polls">My Polls</span>',
			"type": 'PAGE',
			"page": 'my_polls'
		}
		LRS.appendMenuItemToTSMenuItem(sidebarId, options);
		options = {
			"titleHTML": '<span data-i18n="create_poll">Create Poll</span>',
			"type": 'MODAL',
			"modalId": 'create_poll_modal'
		}
		LRS.appendMenuItemToTSMenuItem(sidebarId, options);

		$('#create_poll_modal input[name="feeLRD"]').attr('min', 10);
		$('#create_poll_modal input[name="feeLRD"]').data('default', 10);
		$('#create_poll_modal input[name="feeLRD"]').val(10);
	}

	function _resetPollFee() {
		var options = $(".create_poll_answers").length;
		if(options > 20)
		{
			var fee = (options - 20) + 10;
			$("#create_poll_fee").val(fee);
			$("#create_poll_fee_text").text(fee + " LRD");
		}
		else 
		{
			$("#create_poll_fee").val("10");
			$("#create_poll_fee_text").text("10 LRD");
		}
	}

	$("#create_poll_answers").on("click", "button.btn.remove_answer", function(e) {
		e.preventDefault();

		if ($("#create_poll_answers > .form-group").length == 1) {
			return;
		}

		$(this).closest("div.form-group").remove();
		_resetPollFee();
	});

	$("#create_poll_answers_add").click(function(e) {
		var $clone = $("#create_poll_answers > .form-group").first().clone();

		$clone.find("input").val("");

		$clone.appendTo("#create_poll_answers");
		_resetPollFee();
	});

	function _setMinBalanceForm() {
		var pollType = parseInt($("#create_poll_type").val());
		var mbType = parseInt($("input[name=minBalanceType]:radio:checked").val());

		if (pollType == 0 && mbType == 0) {
			$('#min_voting_balance_label_unit').html($.t('none'));
			$('#create_poll_min_balance').attr('disabled', true);
		} else {
			$('#create_poll_min_balance').attr('disabled', false);
		}
		if ((pollType == 0 && mbType == 1) || pollType == 1) {
			$('#min_voting_balance_label_unit').html($.t('lrd_capital_letters'));
			$('#create_poll_min_balance').attr('name', 'minBalanceLRD');
		}
		if ((pollType == 0 && mbType == 2) || pollType == 2) {
			$('#min_voting_balance_label_unit').html($.t('asset'));
			$('#create_poll_min_balance').attr('name', 'minBalanceQNTf');
		}
		if ((pollType == 0 && mbType == 3) || pollType == 3) {
			$('#min_voting_balance_label_unit').html($.t('currency'));
			$('#create_poll_min_balance').attr('name', 'minBalanceQNTf');
		}
	}

	$("#create_poll_type").change(function() {
		// poll type changed, lets see if we have to include/remove the asset id
		if($("#create_poll_type").val() == "2") {
			$("#create_poll_asset_id_group").css("display", "inline");
			$("#create_poll_ms_currency_group").css("display", "none");
		}
		else if($("#create_poll_type").val() == "3") {
			$("#create_poll_asset_id_group").css("display", "none");
			$("#create_poll_ms_currency_group").css("display", "inline");
		}
		else {
			$("#create_poll_asset_id_group").css("display", "none");
			$("#create_poll_ms_currency_group").css("display", "none");
		}

		if($("#create_poll_type").val() == "0") {
			$("#create_poll_min_balance_type_group").css("display", "block");
		} else {
			$("#create_poll_min_balance_type_group").css("display", "none");
		}
		_setMinBalanceForm();
	});

	$("input[name=minBalanceType]:radio").change(function () {
		var value = $(this).val();

		if(value == "2") {
			$("#create_poll_asset_id_group").css("display", "block");
			$("#create_poll_ms_currency_group").css("display", "none");
		}
		else if(value == "3") {
			$("#create_poll_asset_id_group").css("display", "none");
			$("#create_poll_ms_currency_group").css("display", "block");
		}
		else {
			$("#create_poll_asset_id_group").css("display", "none");
			$("#create_poll_ms_currency_group").css("display", "none");
		}
		_setMinBalanceForm();
	});


	$("body").on("click", ".vote_button[data-poll]", function(e) {
		e.preventDefault();
		var transactionId = $(this).data("poll");

		LRS.sendRequest("getTransaction", {
			"transaction": transactionId
		}, function(response, input) {
			$("#cast_vote_poll_name").text(response.attachment.name);
			$("#cast_vote_poll_description").text(response.attachment.description);
			$("#cast_vote_answers_entry").text("");
			if(response.attachment.minNumberOfOptions != response.attachment.maxNumberOfOptions) {
				var selectText = $.t('poll_select_min_max_options', {
					'min': response.attachment.minNumberOfOptions,
					'max': response.attachment.maxNumberOfOptions
				});
				$("#cast_vote_range").text(selectText);
			} else if (response.attachment.minNumberOfOptions != 1) {
				var selectText = $.t('poll_select_num_options', {
					'num': response.attachment.minNumberOfOptions
				});
				$("#cast_vote_range").text(selectText);
			} else {
				var selectText = $.t('poll_select_one_option');
				$("#cast_vote_range").text(selectText);
			}

			$("#cast_vote_poll").val(response.transaction);
			if(response.attachment.maxRangeValue != 1)
			{
				for(var b=0; b<response.attachment.options.length; b++)
				{
					var html = "<div class='answer_slider' style='padding:6px;background-color:#f9f9f9;border:1px solid #ddd;margin-bottom:4px;'>";
					html += "<label name='cast_vote_answer_"+b+"'>"+String(response.attachment.options[b]).escapeHTML()+"</label> &nbsp;&nbsp;";
					html += "<span class='cast_vote_value label label-default' style='float:right;'>"+response.attachment.minRangeValue+"</span><br/>";
					html += "<input class='form-control' step='1' value='"+response.attachment.minRangeValue+"' max='"+response.attachment.maxRangeValue+"' min='"+response.attachment.minRangeValue+"' type='range'/>";
					html += "</div>";
					$("#cast_vote_answers_entry").append(html);
				}
			}
			else
			{
				for(var b=0; b<response.attachment.options.length; b++)
				{
					$("#cast_vote_answers_entry").append("<div class='answer_boxes'><label name='cast_vote_answer_"+b+"'><input type='checkbox'/>&nbsp;&nbsp;"+String(response.attachment.options[b]).escapeHTML()+"</label></div>");
				}
			}
			$("#cast_vote_modal").modal();
			$("input[type='range']").on("change mousemove", function() {
				$label = $(this).parent().children(".cast_vote_value.label");
				if ($(this).val() > 0) {
					$label.removeClass("label-default");
					$label.addClass("label-primary");
				} else {
					$label.removeClass("label-primary");
					$label.addClass("label-default");
				}
				$label.text($(this).val());
			});
		});
	});

    function layoutPollResults(resultsdata, polldata) {
        var results = resultsdata.results;
        var options = polldata.options;

        if (!results) {
            results = [];
        }
        var rows = "";
        if (results.length) {
            for (var i = 0; i < results.length; i++) {
                var result = results[i];
                rows += "<tr>";
                rows += "<td>" + String(options[i]).escapeHTML() + "</td>";
                var resultStr = "";
                var weightStr = "";
                if (polldata.votingModel == 0) {
                	resultStr = result.result;
                	weightStr = result.weight;
                } else if (polldata.votingModel == 1) {
                	resultStr = LRS.formatAmount(result.result);
                	weightStr = LRS.formatAmount(result.weight);
                } else if (resultsdata.holding) {
                	resultStr = LRS.formatQuantity(result.result, resultsdata.decimals);
                	weightStr = LRS.formatQuantity(result.weight, resultsdata.decimals);
                }
                rows += "<td style='text-align:right;'>" + resultStr + "</td>";
                rows += "<td style='text-align:right;'>" + weightStr + "</td>";
                rows += "</tr>";
            }
        }
        return rows;
    }

    function layoutPollChart(resultsdata, polldata) {
    	$('#followed_polls_poll_chart').empty();
    	if (!resultsdata.results) {
    		return;
    	}

    	var color = d3.scale.category20();
    	var content = [];
    	for(var i=0; i<resultsdata.results.length; i++) {
    		var result = resultsdata.results[i].result;
			if (result == "") {
				continue;
			}
    		content.push({
    			"label": resultsdata.options[i],
    			"value": parseInt(result),
    			"color": color(i)
    		});
    	}

		var pie = new d3pie("followed_polls_poll_chart", {
			"header": {
				"title": {
					"fontSize": 24,
					"font": "open sans"
				},
				"subtitle": {
					"color": "#999999",
					"fontSize": 12,
					"font": "open sans"
				},
				"titleSubtitlePadding": 0
			},
			"footer": {
				"color": "#999999",
				"fontSize": 10,
				"font": "open sans",
				"location": "bottom-left"
			},
			"size": {
				"canvasHeight": 340,
				"canvasWidth": 350
			},
			"data": {
				"sortOrder": "value-desc",
				"smallSegmentGrouping": {
					"enabled": true
				},
				"content": content
			},
			"labels": {
				"outer": {
					"pieDistance": 18
				},
				"inner": {
					"hideWhenLessThanPercentage": 3
				},
				"mainLabel": {
					"fontSize": 11
				},
				"percentage": {
					"color": "#ffffff",
					"decimalPlaces": 0
				},
				"value": {
					"color": "#adadad",
					"fontSize": 11
				},
				"lines": {
					"enabled": true
				}
			},
			"effects": {
				"load": {
					"effect": "none"
				},
				"pullOutSegmentOnClick": {
					"effect": "none",
					"speed": 400,
					"size": 8
				}
			}
		});
    }

    $("#my_polls_table, #voted_polls_table").on("click", "a[data-results]", function(e) {
		e.preventDefault();
		var transactionId = $(this).data("results");

		LRS.sendRequest("getPollResult", {"poll": transactionId, "req":"getPollResult"}, voteModal);
		LRS.sendRequest("getPollVotes", {"poll": transactionId, "req":"getPollVotes"}, voteModal);
		LRS.sendRequest("getPoll", {"poll": transactionId, "req": "getPoll"}, voteModal);
		var resultsdata, votesdata, polldata;

		function voteModal(data, input)
		{
			if(input.req=="getPollResult") resultsdata = data;
			if(input.req=="getPollVotes") votesdata = data;
			if(input.req=="getPoll") polldata = data;

			if(resultsdata !== undefined && votesdata !== undefined && polldata !== undefined)
			{
				$("#poll_results_options").append("<tr><td style='font-weight: bold;width:180px;'><span data-i18n='poll_name'>Poll Name</span>:</td><td><span id='poll_results_poll_name'>"+String(polldata.name).escapeHTML()+"</span></td></tr>");
				$("#poll_results_options").append("<tr><td style='font-weight: bold;width:180px;'><span data-i18n='poll_id'>Poll Id</span>:</td><td><span id='poll_results_poll_id'>"+polldata.poll+"</span></td></tr>");

				$("#poll_results_poll_name").text(String(polldata.name).escapeHTML());
				$("#poll_results_poll_id").text(polldata.poll);

				//$("#poll_results_number_of_voters").text(votesdata.votes.length);

				$("#poll_results_modal").modal();
                var rows = layoutPollResults(resultsdata, polldata);
                $("#poll_results_table tbody").empty().append(rows);

				var votes = votesdata.votes;

				if (!votes) {
					votes = [];
				}

				if (votes.length) 
				{
				
					var head = "";
					head += "<tr>";
					head += "<th data-i18n=\"voter\">Voter</th>";

					for(var b=0; b<polldata.options.length; b++)
					{
						head += "<th>"+String(polldata.options[b].escapeHTML()) + "</th>";
					}
					head += "</tr>";

					$("#poll_voters_table thead").empty().append(head);				

					//$("#votes_cast_count").html("(" + votes.length + ")");

					var rows = "";

					for (var i = 0; i < votes.length; i++) {
						rows += "<tr>";
						var vote = votes[i];

						rows += "<td><a href='#' class='user_info' data-user='" + LRS.getAccountFormatted(vote, "voter") + "'>" + LRS.getAccountTitle(vote, "voter") + "</td>";

						for(var a=0;a<vote.votes.length;a++)
						{
							rows += "<td>" + vote.votes[a] + "</td>";
						}
					}

					$("#poll_voters_table tbody").empty().append(rows);
				}
				else 
				{
					$("#poll_voters_table tbody").empty();
					//$("#votes_cast_count").html("(0)");
				}
			}

		}
	});

	$("body").on("click", ".follow_button[data-follow]", function(e) {
		e.preventDefault();
		$btn = $(this);
		var pollId = $(this).data("follow");

		LRS.sendRequest("getPoll", {"poll": pollId}, function(response) 
		{
			if (response.errorCode) {
				LRS.showModalError($.t("no_poll_found"), $modal);
			} else {
				LRS.saveFollowedPolls(new Array(response), LRS.forms.addFollowedPollsComplete);
			}
			$btn.attr('disabled', true);
		});
	});

	$("#create_poll_modal").on("show.bs.modal", function(e) {
		$('#create_poll_min_balance_type_group').show();
		$('#create_poll_min_balance_type_0').click();

		context = {
			labelText: "Currency",
			labelI18n: "currency",
			inputCodeName: "create_poll_ms_code",
			inputIdName: "create_poll_ms_id",
			inputDecimalsName: "create_poll_ms_decimals",
			helpI18n: "add_currency_modal_help"
		}
		$elems = LRS.initModalUIElement($(this), '.poll_holding_currency', 'add_currency_modal_ui_element', context);

		context = {
			labelText: "Asset",
			labelI18n: "asset",
			inputIdName: "create_poll_asset_id",
			inputDecimalsName: "create_poll_asset_decimals",
			helpI18n: "add_asset_modal_help"
		}
		$elems = LRS.initModalUIElement($(this), '.poll_holding_asset', 'add_asset_modal_ui_element', context);

		var context = {
			labelText: "Finish Height",
			labelI18n: "finish_height",
			helpI18n: "create_poll_finish_height_help",
			inputName: "finishHeight",
			initBlockHeight: LRS.lastBlockHeight + 7000,
			changeHeightBlocks: 500
		}
		var $elems = LRS.initModalUIElement($(this), '.create_poll_finish_height', 'block_height_modal_ui_element', context);
	});


	$("#poll_results_modal").on("show.bs.modal", function(e) {
		$("#poll_results_modal_statistics").show();
		// now lets put the data in the correct place...
	});

	$("#poll_results_modal ul.nav li").click(function(e) {
		e.preventDefault();

		var tab = $(this).data("tab");

		$(this).siblings().removeClass("active");
		$(this).addClass("active");

		$(".poll_results_modal_content").hide();

		var content = $("#poll_results_modal_" + tab);

		content.show();
	});

	$("#poll_results_modal").on("hidden.bs.modal", function(e) {
		$(this).find(".poll_results_modal_content").hide();
		$(this).find("ul.nav li.active").removeClass("active");
		$("#poll_results_statistics_nav").addClass("active");
		$("#poll_results_options").text("");
	});	

	LRS.forms.createPoll = function($modal) {
		var data = LRS.getFormData($modal.find("form:first"));

		var options = [];

		$("#create_poll_answers input.create_poll_answers").each(function() {
			var option = $.trim($(this).val());
			if (option) {
				options.push(option);
			}
		});
		//data["minBalance"] = String(parseInt($("#create_poll_min_balance").val())*100000000);

        var pollType = $("#create_poll_type");
        if(pollType.val() == "0") {
			data["votingModel"] = 0;
			var minBalanceModel = parseInt($('input:radio[name=minBalanceType]:checked').val());
			data["minBalanceModel"] = minBalanceModel;
			if(minBalanceModel == 2) {
                data["holding"] = $("input[name='create_poll_asset_id']").val();
            } else if(minBalanceModel == 3) {
                data["holding"] = $("input[name='create_poll_ms_id']").val();
            }
		} else if(pollType.val() == "1") {
			data["votingModel"] = 1;
			data["minBalanceModel"] = 1;
		} else if(pollType.val() == "2") {
			data["votingModel"] = 2;
			data["holding"] = $("input[name='create_poll_asset_id']").val();
			data["minBalanceModel"] = 2;
		} else if(pollType.val() == "3") {
			data["votingModel"] = 3;
			data["holding"] = $("input[name='create_poll_ms_id']").val();
			data["minBalanceModel"] = 3;
		}

		for (var i = 0; i < options.length; i++) {
			var number;
			if(i < 10) {
                number = "0" + i;
            } else {
                number = i;
            }
			data["option" + (number)] = options[i];
		}

		return {
			"requestType": "createPoll",
			"data": data
		};
	};

	LRS.forms.createPollComplete = function(response, data) {
		if (LRS.currentPage == "polls") {
			var $table = $("#polls_table tbody");
			var rowToAdd = "<tr class='tentative'>";
			rowToAdd += "<td>" + String(data.name).escapeHTML() + " - <strong >" + $.t("pending") + "</strong></td>";
			rowToAdd += "<td>" + String(data.description).escapeHTML() + "</td>";
			rowToAdd += "<td><a href='#' data-user='" + LRS.getAccountFormatted(LRS.accountRS) + "' class='show_account_modal_action user_info'>";
			rowToAdd += LRS.getAccountTitle(LRS.accountRS) + "</a></td>";
			rowToAdd += "<td>" + LRS.formatTimestamp(LRS.toEpochTime()) + "</td>";
			rowToAdd += "<td>&nbsp;</td>";
			rowToAdd += "<td>&nbsp;</td>";
			rowToAdd += "</tr>";

			$table.prepend(rowToAdd);

			if ($("#polls_table").parent().hasClass("data-empty")) {
				$("#polls_table").parent().removeClass("data-empty");
			}
		}
	}

	LRS.forms.castVote = function($modal) {
		var data = LRS.getFormData($modal.find("form:first"));

		var options = Array();

		$("#cast_vote_answers_entry div.answer_slider input").each(function() {
			var option = $.trim($(this).val());
			if(option == 0) option = -128;
			if (option) {
				options.push(option);
			}
		});

		$("#cast_vote_answers_entry div.answer_boxes input").each(function() {
			var option = $(this).is(':checked') ? 1 : -128;
			options.push(option);
		});

		
		data["poll"] = $("#cast_vote_poll").val();
		data["feeLQT"] = String(parseInt($("#cast_vote_fee").val())*100000000);
		data["deadline"] = $("#cast_vote_deadline").val();
		data["secretPhrase"] =  $("#cast_vote_password").val();
		
		for (var i = 0; i < options.length; i++) {
			data["vote" + (i < 10 ? "0" + i : i)] = options[i];
		}
		return {
			"requestType": "castVote",
			"data": data
		};
	}

	LRS.forms.castVoteComplete = function(response, data) {
		if (data.poll) {
			$('.vote_button[data-poll="' + data.poll + '"]').attr('disabled', true);
		}
	}


	// a lot of stuff in followed polls, lets put that here
	LRS.followedPolls = [];
	LRS.followedPollIds = [];
	LRS.currentPoll = {};
	var currentPollId = 0;

	LRS.pages.followed_polls = function(callback) {
		$(".content.content-stretch:visible").width($(".page:visible").width());

		if (LRS.databaseSupport) {
			LRS.followedPolls = [];
			LRS.followedPollIds = [];

			LRS.database.select("polls", null, function(error, polls) {
				//select already bookmarked assets
				$.each(polls, function(index, poll) {
					LRS.cachePoll(poll);
				});
				
					LRS.loadFollowedPollsSidebar(callback);
			});
		} 
	}

	LRS.cachePoll = function(poll) {
		if (LRS.followedPollIds.indexOf(poll.poll) != -1) {
			return;
		}

		LRS.followedPollIds.push(poll.poll);

			poll.groupName = "";

		var poll = {
			"poll": String(poll.poll),
			"name": String(poll.name).toLowerCase(),
			"description": String(poll.description),
			"account": String(poll.account),
			"accountRS": String(poll.accountRS),
			"finishHeight": String(poll.finishHeight)
		};

		LRS.followedPolls.push(poll);
	}

	LRS.forms.addFollowedPoll = function($modal) {
		var data = LRS.getFormData($modal.find("form:first"));

		data.id = $.trim(data.id);

		if (!data.id) {
			return {
				"error": $.t("error_poll_id_required")
			};
		}

		if (!/^\d+$/.test(data.id) && !/^LRD\-/i.test(data.id)) {
			return {
				"error": $.t("error_poll_id_invalid")
			};
		}
		else {
			LRS.sendRequest("getPoll", {
				"poll": data.id
			}, function(response) {
				if (response.errorCode) {
					LRS.showModalError($.t("no_poll_found"), $modal);
				} else {
					LRS.saveFollowedPolls(new Array(response), LRS.forms.addFollowedPollsComplete);
				}
			});
		}
	}

	LRS.forms.addFollowedPollsComplete = function(newPolls, submittedPolls) {
		LRS.pollSearch = false;

		if (newPolls.length == 0) {
			LRS.closeModal();
			$.growl($.t("error_poll_already_bookmarked", {
				"count": submittedPolls.length
			}), {
				"type": "danger"
			});
			$("#followed_polls_sidebar a.active").removeClass("active");
			$("#followed_polls_sidebar a[data-poll=" + submittedPolls[0].poll + "]").addClass("active").trigger("click");
			return;
		} else {
			LRS.closeModal();

			var message = "";
			if (newPolls.length == 1) {
				message += $.t("success_poll_followed_one");
			} else {
				message += $.t("success_poll_followed", { "count": newPolls.length });
			}

			if (!LRS.databaseSupport) {
				message += " " + $.t("error_poll_save_db");
			}

			$.growl(message, {
				"type": "success"
			});

			LRS.loadFollowedPollsSidebar(function(callback) {
				$("#followed_polls_sidebar a.active").removeClass("active");
				$("#followed_polls_sidebar a[data-asset=" + newPolls[0].poll + "]").addClass("active").trigger("click");
			});
		}
	}

	LRS.saveFollowedPolls = function(polls, callback) {
		var newPollIds = [];
		var newPolls = [];

		$.each(polls, function(key, poll) {
			var newPoll = {
				"poll": String(poll.poll),
				"name": String(poll.name),
				"account": String(poll.account),
				"accountRS": String(poll.accountRS),
				"description": String(poll.description),
				"finishHeight": String(poll.finishHeight)
			};

			newPolls.push(newPoll);

			if (LRS.databaseSupport) {
				newPollIds.push({
					"poll": String(poll.poll)
				});
			}
		});

		if (!LRS.databaseSupport) {
			if (callback) {
				callback(newPolls, polls);
			}
			return;
		}

		LRS.database.select("polls", newPollIds, function(error, existingPolls) {
			var existingIds = [];

			if (existingPolls.length) {
				$.each(existingPolls, function(index, poll) {
					existingIds.push(poll.poll);
				});

				newPoll = $.grep(newPolls, function(v) {
					return (existingIds.indexOf(v.poll) === -1);
				});
			}

			if (newPolls.length == 0) {
				if (callback) {
					callback([], polls);
				}
			} else {
				LRS.database.insert("polls", newPolls, function(error) {
					$.each(newPolls, function(key, poll) {
						poll.name = poll.name.toLowerCase();
						LRS.followedPollIds.push(poll.poll);
						LRS.followedPolls.push(poll);
					});

					if (callback) {
						//for some reason we need to wait a little or DB won't be able to fetch inserted record yet..
						setTimeout(function() {
							callback(newPolls, polls);
						}, 50);
					}
				});
			}
		});
	}

	LRS.positionFollowedPollsSidebar = function() {
		$("#followed_polls_sidebar").parent().css("position", "relative");
		$("#followed_polls_sidebar").parent().css("padding-bottom", "5px");
		//$("#asset_exchange_sidebar_content").height($(window).height() - 120);
		$("#followed_polls_sidebar").height($(window).height() - 120);
	}

	//called on opening the asset exchange page and automatic refresh
	LRS.loadFollowedPollsSidebar = function(callback) {
		if (!LRS.followedPolls.length) {
			LRS.pageLoaded(callback);
			$("#followed_polls_sidebar_content").empty();
			$("#no_poll_selected, #loading_poll_data, #no_poll_search_results, #poll_details").hide();
			$("#no_polls_available").show();
			$("#followed_polls_page").addClass("no_polls");
			return;
		}

		var rows = "";

		$("#followed_polls_page").removeClass("no_polls");

		LRS.positionFollowedPollsSidebar();

		LRS.followedPolls.sort(function(a, b) {
				if (a.name > b.name) {
					return 1;
				} else if (a.name < b.name) {
					return -1;
				} else {
					return 0;
				}
		});

		var lastGroup = "";
		var ungrouped = true;
		var isClosedGroup = false;

		var isSearch = false;
		var searchResults = 0;

		for (var i = 0; i < LRS.followedPolls.length; i++) {
			var poll = LRS.followedPolls[i];

			rows += "<a href='#' class='list-group-item list-group-item-" + "ungrouped" + " not_owns_asset" + "' ";
			rows += "data-cache='" + i + "' ";
			rows += "data-poll='" + String(poll.poll).escapeHTML() + "'";
			rows += (isClosedGroup ? " style='display:none'" : "") + " data-closed='" + isClosedGroup + "'>";
			rows += "<h4 class='list-group-item-heading'>" + poll.name.escapeHTML() + "</h4>";

			if(LRS.lastBlockHeight > parseInt(poll.finishHeight))
			{
				rows += "<p class='list-group-item-text'><span data-i18n=\"completed\">Completed</span></p>";
			}
			else
			{
				rows += "<p class='list-group-item-text'><span data-i18n=\"blocks_left\">Blocks Left</span>: " + (parseInt(poll.finishHeight)-LRS.lastBlockHeight) + "</p>";
			}
			rows += "</a>";
		}

		var active = $("#followed_polls_sidebar a.active");

		if (active.length) {
			active = active.data("poll");
		} else {
			active = false;
		}
		$("#followed_polls_sidebar_content").empty().append(rows);

		if (active) {
			$("#followed_polls_sidebar a[data-poll=" + active + "]").addClass("active");
		}
		$("#followed_polls_sidebar_search").hide();

		LRS.pageLoaded(callback);
	}

	LRS.incoming.followed_polls = function() {
		if (!LRS.viewingPoll) {
			//refresh active asset
			var $active = $("#followed_polls_sidebar a.active");

			if ($active.length) {
				$active.trigger("click", [{
					"refresh": true
				}]);
			}
		} else {
			LRS.loadPoll(LRS.viewingPoll, true);
		}
	}

	$("#followed_polls_sidebar").on("click", "a", function(e, data) {
		e.preventDefault();

		currentPollID = String($(this).data("poll")).escapeHTML();

		//refresh is true if data is refreshed automatically by the system (when a new block arrives)
		if (data && data.refresh) {
			var refresh = true;
		} else {
			var refresh = false;
		}

		//clicked on a group
		if (!currentPollID) {
			if (LRS.databaseSupport) {
				var group = $(this).data("groupname");
				var closed = $(this).data("closed");
				var $links = $("#followed_polls_sidebar a.list-group-item-ungrouped");

				if (!group) {
					group = "undefined";
				}

				if (closed) {
					var pos = LRS.closedGroups.indexOf(group);
					if (pos >= 0) {
						LRS.closedGroups.splice(pos);
					}
					$(this).data("closed", "");
					$(this).find("i").removeClass("fa-angle-right").addClass("fa-angle-down");
					$links.show();
				} else {
					LRS.closedGroups.push(group);
					$(this).data("closed", true);
					$(this).find("i").removeClass("fa-angle-down").addClass("fa-angle-right");
					$links.hide();
				}

				LRS.database.update("data", {
					"contents": LRS.closedGroups.join("#")
				}, [{
					"id": "closed_groups"
				}]);
			}

			return;
		}

		if (LRS.databaseSupport) {
			LRS.database.select("polls", [{
				"poll": currentPollID
			}], function(error, poll) {
				if (poll && poll.length && poll[0].poll == currentPollID) {
					LRS.loadPoll(poll[0], refresh);
				}
			});
		} else {
			LRS.sendRequest("getPoll+", {
				"poll": currentPollID
			}, function(response, input) {
				if (!response.errorCode && response.poll == currentPollID) {
					LRS.loadPoll(response, refresh);
				}
			});
		}
	});

	$("#followed_polls_sidebar_context").on("click", "a", function(e) {
		e.preventDefault();
		var pollId = LRS.selectedContext.data("poll");
		var option = $(this).data("option");

		LRS.closeContextMenu();
		if (option == "remove_from_bookmarks") {
			LRS.database.delete("polls", [{
				"poll": pollId
			}], function() {
				setTimeout(function() {
					LRS.loadPage("followed_polls");
					$.growl($.t("success_poll_bookmark_removal"), {
						"type": "success"
					});
				}, 50);
			});
		}
	});

	LRS.loadPoll = function(poll, refresh) {
		var pollId = poll.poll;
		LRS.currentPoll = poll;
		LRS.currentSubPage = pollId;

		if (!refresh) {
			$("#followed_polls_sidebar a.active").removeClass("active");
			$("#followed_polls_sidebar a[data-poll=" + pollId + "]").addClass("active");

			$("#no_poll_selected, #loading_poll_data, #no_polls_available, #no_poll_search_results").hide();
			$("#poll_details").show().parent().animate({
				"scrollTop": 0
			}, 0);

			$("#poll_account").html("<a href='#' data-user='" + LRS.getAccountFormatted(poll, "account") + "' class='user_info'>" + LRS.getAccountTitle(poll, "account") + "</a>");
			$("#poll_id").html(poll.poll.escapeHTML());

			$("#followed_polls_poll_name").html(String(poll.name).escapeHTML());
			$("#poll_description").html(String(poll.description).autoLink());
			$(".poll_name").html(String(poll.name).escapeHTML());
			$("#vote_poll_link .vote_button").data("poll", pollId);

			if(poll.finishHeight > LRS.lastBlockHeight) {
				$("#vote_poll_link").show();
			} else {
				$("#vote_poll_link").hide();
			}

			$("#followed_polls_poll_results tbody").empty();
			$("#followed_polls_votes_cast tbody").empty();
			$("#followed_polls_poll_results").parent().addClass("data-loading").removeClass("data-empty");
			$("#followed_polls_votes_cast").parent().addClass("data-loading").removeClass("data-empty");

			$(".data-loading img.loading").hide();

			setTimeout(function() {
				$(".data-loading img.loading").fadeIn(200);
			}, 200);

			if (LRS.databaseSupport) {
				LRS.sendRequest("getPoll", {
					"poll": pollId
				}, function(response) {
					if (!response.errorCode) {
						if (response.poll != poll.poll || response.account != poll.account || response.accountRS != poll.accountRS || response.description != poll.description || response.name != poll.name) {
							LRS.database.delete("polls", [{
								"poll": poll.poll
							}], function() {
								setTimeout(function() {
									LRS.loadPage("followed_polls");
									$.growl("Invalid poll.", {
										"type": "danger"
									});
								}, 50);
							});
						}
					}
				});
			}

			if (poll.viewingPoll) {
				$("#followed_polls_bookmark_this_poll").show();
				LRS.viewingPoll = poll;
			} else {
				$("#followed_polls_bookmark_this_poll").hide();
				LRS.viewingPoll = false;
			}
		}

		LRS.loadPollResults(pollId, refresh);
		LRS.loadPollVotes(pollId, refresh);
		_setVoteButtonStates();
	}

	LRS.loadPollResults = function(pollId, refresh) {
		LRS.sendRequest("getPoll+" + pollId, {
			"poll": pollId
		}, function(polldata, input) {

			LRS.sendRequest("getPollResult+" + pollId, {
				"poll": pollId
			}, function(response, input) {
                var rows = layoutPollResults(response, polldata);
                layoutPollChart(response, polldata);
                $("#followed_polls_poll_results tbody").empty().append(rows);
				LRS.dataLoadFinished($("#followed_polls_poll_results"), !refresh);
			});
		});
	}

	LRS.loadPollVotes = function(pollId, refresh)
	{
		LRS.sendRequest("getPoll+" + pollId, {
			"poll": pollId
		}, function(polldata, input) {
			var maxVotes = 50;
			LRS.sendRequest("getPollVotes+" + pollId, {
				"poll": pollId,
				"firstIndex": 0,
				"lastIndex": maxVotes
			}, function(votesdata, input) {

				var votes = votesdata.votes;

				if (!votes) {
					votes = [];
				}

				if (votes.length) {
					
					var head = "";
					head += "<tr>";
					head += "<th data-i18n=\"voter\">Voter</th>";

					for(var b=0; b<polldata.options.length; b++)
					{
						head += "<th>"+String(polldata.options[b].escapeHTML()) + "</th>";
					}
					head += "</tr>";

					$("#followed_polls_votes_cast thead").empty().append(head);				

					if (votes.length > maxVotes) {
						var lengthStr = String(maxVotes) + "+";
						votes.pop();
					} else {
						var lengthStr = String(votes.length);
					}
					$("#votes_cast_count").html("(" + lengthStr + ")");

					var rows = "";

					for (var i = 0; i < votes.length; i++) {
						rows += "<tr>";
						var vote = votes[i];

						rows += "<td><a href='#' class='user_info' data-user='" + LRS.getAccountFormatted(vote, "voter") + "'>" + LRS.getAccountTitle(vote, "voter") + "</td>";

						for(var a=0;a<vote.votes.length;a++)
						{
							rows += "<td>" + vote.votes[a] + "</td>";
						}
					}

					$("#followed_polls_votes_cast tbody").empty().append(rows);
				} else {
					$("#followed_polls_votes_cast tbody").empty();
					$("#votes_cast_count").html("(0)");

				}

				LRS.dataLoadFinished($("#followed_polls_votes_cast"), !refresh);
			});
		})
	}

	return LRS;
}(LRS || {}, jQuery));

