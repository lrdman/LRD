#!/bin/sh
java -cp classes:lib/*:conf lrd.Lrd
