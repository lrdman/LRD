#!/bin/sh
java -cp classes:lib/*:conf -Dlrd.runtime.mode=desktop lrd.Lrd
